# Unit tests for style and formatting objects.
